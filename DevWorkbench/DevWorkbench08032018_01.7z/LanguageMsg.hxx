
#ifndef LANGUAGEMSG_HXX_
#define LANGUAGEMSG_HXX_
#include <string>
enum{SPAN, ENGL};

struct Msg
{
   int id_msg;
   std::string msg;
   static int current_languange;
};

int Msg::current_languange = SPAN;

enum{
 FILE_TEXT     =     1
,EDIT    =      2
,SEARCH    =    3
,PROJECT   =    4
,VIEW      =    5
,GO        =    6
,TASK      =    7
,PLUGIN    =    8
,CONFIGURATION= 9
,HELP       =   10
,NEW_FILE   =   11
,OPEN_FILE   =  12
,SAVE_AS    =   13
,SAVE      =    14
,PRINT      =   15
,EXIT      =    16
,SAVE_CURRENT_FILE_QUESTION =17
,YES           =18
,NO            =19
,CANCEL       = 20
,FILE_REPLACE =      21
,CUT          =22
,PASTE        =23
,COPY        = 24
,FIND       =  25
,REPLACE   =   26
,MAX_TEXT
};
static Msg span[]=
{
  {FILE_TEXT         , "Archivo"},
  {EDIT          , "Editar" },
  {SEARCH        , "Buscar" },
  {PROJECT       , "Proyecto" },
  {VIEW          , "Ver" },
  {GO            , "Ir" },
  {TASK          , "Tarea(s)" },
  {PLUGIN        , "plugins" },
  {CONFIGURATION , "Configuracion" },
  {HELP          , "Ayuda" },
  {NEW_FILE      , "Crear Archivo"},
  {OPEN_FILE     , "Abrir Archivo "},
  {SAVE_AS       , "Guardar Como.."},
  {SAVE          , "Guardar "},
  {PRINT         , "Imprimir"},
  {EXIT          , "Salir"},
  {SAVE_CURRENT_FILE_QUESTION , "Deseas Guardar el archivo actual?"},
  {YES           ,"Si"},
  {NO            , "No"},
  {CANCEL        , "Cancelar"},
  {FILE_REPLACE  , "Quieres reemplazar el archivo existente?"},
	{ CUT      , "Cortar"},
	{ PASTE    , "Pegar"},
	{ COPY     , "Copiar"},
	{ FIND     , "Buscar"},
	{ REPLACE  , "Reemplazar"}


};

static Msg engl[]=
{
  {FILE_TEXT          , "File"},
  {EDIT          , "Edit" },
  {SEARCH        , "Search" },
  {PROJECT       , "Project" },
  {VIEW          , "View" },
  {GO            , "go" },
  {TASK          , "Task" },
  {PLUGIN        , "plugins" },
  {CONFIGURATION , "Configuration" },
  {HELP          , "Help" },
  {NEW_FILE      , "New File"},
  {OPEN_FILE     , "Open File"},
  {SAVE_AS       , "Save AS..."},
  {SAVE          , "save"},
  {PRINT         , "Print"},
  {EXIT          , "Exit"},
  {SAVE_CURRENT_FILE_QUESTION          , "Do you wish to close the current change on this file?"},
  {YES           ,"yes"},
  {NO            , "No"},
  {CANCEL        , "Cancel"},
  {FILE_REPLACE  , "do you want to replace the current file for this??"},
	{ CUT      , "Cortar"},
	{ PASTE    , "Pegar"},
	{ COPY     , "Copiar"},
	{ FIND     , "Buscar"},
	{ REPLACE  , "Reemplazar"}
};

inline static void set_current_language(int lang)
{
	switch(lang)
	{
	case SPAN:
		Msg::current_languange=SPAN;
		break;
	case ENGL:
		Msg::current_languange=ENGL;
		break;
	default:
		return;
	}
}


inline static const char *getString(const int constant_value_of_string)
{
  if(constant_value_of_string-1 >= 0 && constant_value_of_string-1 < MAX_TEXT)
	  switch(Msg::current_languange)
	  {
	  case SPAN:
		  return span[constant_value_of_string-1].msg.c_str();
	  case ENGL:
		  return engl[constant_value_of_string-1].msg.c_str();
	  }
  return "INVALID";
}


#endif /* LANGUAGEMSG_HXX_ */

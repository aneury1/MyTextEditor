#include "MenuBar.h"

void newFile(Fl_Widget *w, void *p)
{

}


Fl_Menu_Item  default_menu_items[]=
{
	{"&File"              , 0                  , 0                      , 0, FL_SUBMENU     },
	{"&New File"          , 0                  , (Fl_Callback *) newFile                    },
	{"&Open File"         , FL_COMMAND + 'o'   , (Fl_Callback *) newFile                    },
	{"&Select Folder "    , 0                  , (Fl_Callback *) newFile                    },
	{"&Select Workspace"  , 0                  , (Fl_Callback *) newFile,0 ,FL_MENU_DIVIDER },
	{"&Save as..."        , 0                  , (Fl_Callback *) newFile                    },
	{"&save  "            , FL_COMMAND + 's'   , (Fl_Callback *) newFile                    },
	{"&Save Project  "    , 0                  , (Fl_Callback *) newFile                    },
	{"&Save workspace  "  , 0                  , (Fl_Callback *) newFile,0 ,FL_MENU_DIVIDER },
	{"&print  "           , FL_COMMAND + 'p'   , (Fl_Callback *) newFile,0 ,FL_MENU_DIVIDER },
	{"&Configuration  "   , 0                  , (Fl_Callback *) newFile                    },
	{"&Exit  "            , 0                  , (Fl_Callback *) newFile                    },
	{0}, ///\ End Menu File

	{"&Edit"              , 0                  , 0                      , 0, FL_SUBMENU     },
	{"&Undo"              , 0                  , (Fl_Callback *) newFile                    },
	{"&Redo"              , 0                  , (Fl_Callback *) newFile                    },
	{"&Compare "          , 0                  , (Fl_Callback *) newFile,0 ,FL_MENU_DIVIDER },
	{"&Copy"              , 0                  , (Fl_Callback *) newFile                    },
	{"&Cut"               , 0                  , (Fl_Callback *) newFile                    },
	{"&paste"             , 0                  , (Fl_Callback *) newFile                    },
	{0}, ///\ End Menu Edit

	{"&Search"                    , 0                  , 0                      , 0, FL_SUBMENU     },
	{"&find"                      , 0                  , (Fl_Callback *) newFile                    },
	{"&find in files"             , 0                  , (Fl_Callback *) newFile                    },
	{"&Compare files "            , 0                  , (Fl_Callback *) newFile,0 ,FL_MENU_DIVIDER },
	{"&replace"                   , 0                  , (Fl_Callback *) newFile                    },
	{"&replace in files"          , 0                  , (Fl_Callback *) newFile                    },
	{"&search on internet engine" , 0                  , (Fl_Callback *) newFile                    },
	{0}, ///\ End Menu Edit



	{0}
};










const char *getTextTranslate(const char *text)
{
   return text;
}

MenuBar::MenuBar(GlobalDataStructure* data):Fl_Menu_Bar(0,0,data->main_window->w(), 48), data(data)
{
   color(0x50555bFF);
   textcolor(255);
   copy(default_menu_items);
}

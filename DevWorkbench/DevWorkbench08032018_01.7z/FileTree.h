/*
 * FileTree.h
 *
 *  Created on: Aug 3, 2018
 *      Author: aperez
 */

#ifndef FILETREE_H_
#define FILETREE_H_
#include <FL/Fl_Widget.h>
#include <FL/Fl_Tree.h>


class FileTree : public Fl_Tree {

public:
	FileTree(int X, int Y, int W, int H, const char *L=0);
	Fl_Tree_Item *add(const char *path);
	Fl_Tree_Item *add(const char *path, Fl_Tree_Item *newitem);
};

#endif /* FILETREE_H_ */

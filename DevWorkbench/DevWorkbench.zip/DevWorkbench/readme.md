# what is DevWorkbench?

DevWorbench is a text editor with sintax highlight that help user to edit it text with style. 

## why exist this project? 

the reason is I want to make an editor that has some feature that other provide without clutter with other feature that are not 
needed by me, and in addition I want to learn how editor like this work internally.

## how to build it?

in order to build it, you need the next requirements.
* premake version   depends  on premake ** * ** .lua ` * ` symbols means the  version to use.

** Requirements **
* c++ Compiler
  * GCC
  * Mingw( `Mingw64`, `Mingw32`, `msys2`)
  * MSVC
* FLTK 1.3.4 ** or higher **

## characteristic

1. Sintax Highlight
1. Editor Color configuration(TODO)
1. Build command(TODO)
1. Project & Workspace configuration(TODO)
1. Plugin System(TODO)


## Feedback

* in case you want please file a bug in GitHubs issues

## Relate Project 

this project use FLTK in order to create an multiplatform code.

## License

Author :Aneury p. 

Licensed under @MIT License
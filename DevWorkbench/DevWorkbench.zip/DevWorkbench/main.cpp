#include "GlobalStructure.hxx"
#include <FL/Fl.h>

#include <Fl/Fl_Button.h>





int main(int argc, char *argv[])
{
   ///_data.main_window.add(_data.main_menu);
   _data.main_window->end();
   _data.main_window->show(argc,argv);
   return Fl::run();
}

/*
 * NativeFileChooser.h
 *
 *  Created on: Aug 2, 2018
 *      Author: aperez
 */

#ifndef THIRD_PARTY_NATIVEFILECHOOSER_H_
#define THIRD_PARTY_NATIVEFILECHOOSER_H_

#include <string>

class NativeFileChooser
{

 public:

 static const char *getFileChoosen();
 static std::string getFileChoosen2();
};

#endif /* THIRD_PARTY_NATIVEFILECHOOSER_H_ */

/*
 * NativeFileChooser.cpp
 *
 *  Created on: Aug 2, 2018
 *      Author: aperez
 */
#include <string.h>
#include <NativeFileChooser.h>
#ifdef __WIN32__
#include <windows.h>

#else


#endif
const char *NativeFileChooser::getFileChoosen()
{
#ifdef __WIN32__
	OPENFILENAME ofn ;
	char szFile[100] ;
	ZeroMemory( &ofn , sizeof( ofn));
	ofn.lStructSize = sizeof ( ofn );
	ofn.hwndOwner = NULL  ;
	ofn.lpstrFile = szFile ;
	ofn.lpstrFile[0] = '\0';
	ofn.nMaxFile = sizeof( szFile );
	ofn.lpstrFilter = "All\0*.*\0Text\0*.TXT\0";
	ofn.nFilterIndex =1;
	ofn.lpstrFileTitle = NULL ;
	ofn.nMaxFileTitle = 0 ;
	ofn.lpstrInitialDir=NULL ;
	ofn.Flags = OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST ;
	GetOpenFileName( &ofn );
	MessageBox ( NULL , ofn.lpstrFile , "File Name" , MB_OK);
	const char *ret =ofn.lpstrFile;
	return ret;
#else

#endif
}


std::string NativeFileChooser::getFileChoosen2()
{
#ifdef __WIN32__
	OPENFILENAME ofn ;
	char szFile[100] ;
	ZeroMemory( &ofn , sizeof( ofn));
	ofn.lStructSize = sizeof ( ofn );
	ofn.hwndOwner = NULL  ;
	ofn.lpstrFile = szFile ;
	ofn.lpstrFile[0] = '\0';
	ofn.nMaxFile = sizeof( szFile );
	ofn.lpstrFilter = "All\0*.*\0Text\0*.TXT\0";
	ofn.nFilterIndex =1;
	ofn.lpstrFileTitle = NULL ;
	ofn.nMaxFileTitle = 0 ;
	ofn.lpstrInitialDir=NULL ;
	ofn.Flags = OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST|OFN_CREATEPROMPT;
	GetOpenFileName( &ofn );
	////MessageBox ( NULL , ofn.lpstrFile , "File Name" , MB_OK);
	std::string ret= ofn.lpstrFile;
	return ret;
#else

#endif
}



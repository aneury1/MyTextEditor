#include <FL/Fl_File_Chooser.H>
#include <FL/Fl_Native_File_Chooser.H>
#include <FL/Fl_File_Browser.H>
#include <FL/Fl_Tabs.h>
#include <FL/Fl_Button.h>
#include <FL/Fl_Menu_Item.h>
#include <Fl/Fl_ask.H>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <io.h>
#include <fstream>
#include "NativeFileChooser.h"
#include "StyleMap.hxx"
#include "devWorkBench.hxx"
#include "LanguageMsg.hxx"

#include "FL_Gel_Tabs.h"

using namespace std;
devWorkBench* devWorkBench::singleObject=nullptr;

char filename[256]={'\0'};
bool is_inserted;
bool is_deleted;
int last_pos_of_cursor;

void modify_callback(int pos, int nInserted, int nDeleted, int nRestyled, const char* deletedText, void* cbArg)
{
   is_inserted = nInserted!=0;
   is_deleted  = nDeleted !=0;
   last_pos_of_cursor = pos;
}

void exit(Fl_Widget *w, void *cb_dat)
{
	::exit(-1);
}


void create_new_file(Fl_Widget *w, void *cb_dat)
{
	bool continue_ = false;
    if(is_inserted!= false || is_deleted !=false)
	   {
    	  switch( fl_choice(getString(SAVE_CURRENT_FILE_QUESTION), getString(NO), getString(YES),getString(CANCEL)))
    	  {
    	     case 1:
    	    	 continue_ = true;
    	    	 ///fl_ask("si");
    	    	 if(filename[0]=='\0')
    	    	 {
    	    		   std::string src=NativeFileChooser::getFileChoosen2().c_str();
                       ifstream fs(src.c_str());
                       if(fs.is_open())
                       {
                    	   switch( fl_choice(getString(FILE_REPLACE), getString(NO), getString(YES),getString(CANCEL)))
                    	    {
                    	         case 1:
                    	        	 continue_= true;
                    	    }
                       }

                         if(continue_==true)
                         {
						   fstream ofs(src.c_str(), ios::trunc |ios::out);
						   ofs.write(devWorkBench::get()->getTextFromCurrentEditor(), strlen(devWorkBench::get()->getTextFromCurrentEditor()));
						   ofs.flush();
						   ofs.close();
                         }
                         else
                         {
                        	 return;
                         }
    	    	 }
    	    	 else
    	    	 {
					   fstream sav(filename, ios::trunc|ios::out);
					   sav.write(devWorkBench::get()->getTextFromCurrentEditor(), strlen(devWorkBench::get()->getTextFromCurrentEditor()));
					   sav.flush();
					   sav.close();
    	    	 }
    	    	 break;
    	     case 2:
    	    	 continue_ =false;
    	    	 ///fl_ask("cancelar");
    	    	 break;
    	     default:
    	    	 ///fl_ask("no");
    	    	 memset(filename, 0x00, 256);
    	    	 continue_=true;
    	    	 break;
    	  }
	   }

    if(continue_ ==true)
    {
    	devWorkBench::get()->clearDefaultEditor();
    	is_inserted = is_deleted = false;
    }

}

void open_file(Fl_Widget *w, void *cb_dat)
{
	create_new_file(w, cb_dat);
	std::string src=NativeFileChooser::getFileChoosen2().c_str();
	fstream read(src.c_str(), ios::in);
	int len =0;
	if(read.is_open())
	{
		char *buffer =nullptr;
		read.seekg(0, ios::end);
		len = read.tellg();
		read.seekg(0, ios::beg);
		buffer = new char[len+1];
		memset(buffer, 0x00, len+1);
		read.read(buffer, len);
		devWorkBench::get()->setTextOnCurrentEditor(buffer);
		delete []buffer;
		read.close();
	}
	else
	{
		///fl_ask("file is not open");
	}
}

void save_as(Fl_Widget *w, void *cb_dat)
{
	std::string src=NativeFileChooser::getFileChoosen2().c_str();
	fstream write(src.c_str(), ios::out|ios::trunc);
	if(write.is_open())
	{
	   write.seekp(0, ios::beg);
	   fstream ofs(src.c_str(), ios::trunc |ios::out);
	   ofs.write(devWorkBench::get()->getTextFromCurrentEditor(), strlen(devWorkBench::get()->getTextFromCurrentEditor()));
	   ofs.flush();
	   ofs.close();

	}
	else
	{
		///fl_ask("file is not open");
	}
}


Fl_Menu_Item default_menu[]=
{
  { getString(FILE_TEXT)       , 0, 0, 0, FL_SUBMENU},
  { getString(NEW_FILE)   , FL_CTRL+'n' ,  create_new_file      , (void*)1  , /*FL_MENU_DIVIDER*/0},
  { getString(OPEN_FILE)  , FL_CTRL+'o'  , open_file            , (void*)2   , FL_MENU_DIVIDER},
  { getString(SAVE_AS)    , FL_CTRL+'n'  , save_as              , (void*)3   , /*FL_MENU_DIVIDER*/0},
  { getString(SAVE)       ,     0        , save_as              , (void*)4   ,  FL_MENU_DIVIDER},
  { getString(PRINT)      , FL_CTRL+'p'  , NULL/*the_cb*/       , (void*)5   , FL_MENU_DIVIDER},
  { getString(EXIT)       ,           0  , exit                 , (void*)6   , /*FL_MENU_DIVIDER*/0},
  {0}, ///END FILE MENU.
  { getString(EDIT), 0, 0, 0, FL_SUBMENU},
  { getString(COPY)   , FL_CTRL+'c' ,  NULL      , (void*)1  , /*FL_MENU_DIVIDER*/0},
  { getString(PASTE)   , FL_CTRL+'v' ,  NULL      , (void*)1  , /*FL_MENU_DIVIDER*/0},
  { getString(CUT)   , FL_CTRL+'x' ,  NULL      , (void*)1  , /*FL_MENU_DIVIDER*/0},

  {0},
  {getString(SEARCH), 0, 0, 0, FL_SUBMENU},
  { getString(FIND)   , FL_CTRL+'f' ,  NULL      , (void*)1  ,  FL_MENU_DIVIDER },
  { getString(REPLACE)   , FL_CTRL+'d' ,  NULL      , (void*)1  , /*FL_MENU_DIVIDER*/0},
  {0},
  {getString(PROJECT), 0, 0, 0, FL_SUBMENU|FL_MENU_INACTIVE},
  {0},
  {getString(VIEW), 0, 0, 0, FL_SUBMENU|FL_MENU_INACTIVE},
  {0},
  {getString(GO), 0, 0, 0, FL_SUBMENU|FL_MENU_INACTIVE},
  {0},
  {getString(TASK), 0, 0, 0, FL_SUBMENU|FL_MENU_INACTIVE},
  {0},
  {getString(PLUGIN), 0, 0, 0, FL_SUBMENU|FL_MENU_INACTIVE},
  {0},
  {getString(CONFIGURATION), 0, 0, 0, FL_SUBMENU|FL_MENU_INACTIVE},
  {0},
  {getString(HELP), 0, 0, 0, FL_SUBMENU},
  {0},
  {0}///end of items
};






devWorkBench::devWorkBench() : Fl_Double_Window(1,1,Fl::w(), Fl::h(), "DevWorkBench")
{
  ////set_current_language(ENGL);
  this->main_mdi=nullptr;
  this->editor=nullptr;
  front_text_buffer=nullptr;
  colored_text_buffer=nullptr;
 // this->workbench = nullptr;
  menubar= new Fl_Menu_Bar(0,0,w(),32);
  menubar->textsize(16);
  menubar->textfont(FL_TIMES);
  menubar->copy(default_menu);
  this->add(menubar);
 // this->add(status_bar);
  this->color(BLACK_COLOR_MAP.background_color);
  menubar->color(BLACK_COLOR_MAP.menu_bar_color, BLACK_COLOR_MAP.menu_bar_post_bg);
  menubar->textcolor(BLACK_COLOR_MAP.text_menu_bar_color);
  menubar->box(FL_THIN_UP_BOX);
  //createDefaultEditor();
  addMDIInterface();
  this->resizable(main_mdi);
}


/*
 * this is temporal until I realize what should be done in order to have good tabulation panel.
 * I need to get know how to use Fl_Group in order to make it, but for some reason the Fl_Tab
 * is show some weird trick;
 *
 */
void devWorkBench::createDefaultEditor()
{
	  editor = new Fl_Text_Editor(0,menubar->h()+4,w()-1,h()-menubar->h()-60);
	  editor->textcolor(0x00000000);
	  front_text_buffer = new Fl_Text_Buffer(16 *1024);///16 kb could be enough
	  editor->buffer(this->front_text_buffer);
	  colored_text_buffer=new Fl_Text_Buffer(16 *1024);///16 kb could be enough
	  this->add(editor);
	  front_text_buffer->add_modify_callback(modify_callback, this);
	  front_text_buffer->call_modify_callbacks();
	  editor->color(BLACK_COLOR_MAP.text_editor_bg_color);
	  editor->textcolor(BLACK_COLOR_MAP.text_color);
	  editor->box(FL_FLAT_BOX);
	  editor->textsize(20);
}

void devWorkBench::addMDIInterface()
{
   this->end();
   this->main_mdi = new MDIGroup(0, menubar->h()+1, this->w(), this->h(),"");
   //this->main_mdi->box(FL_BORDER_BOX);
   //this->main_mdi->color(BLACK_COLOR_MAP.background_color);
   this->begin();

   main_mdi->begin();
   fileTree = new FileTree(0,1,200,h()-100);
   fileTree->color(BLACK_COLOR_MAP.background_color);
   fileTree->labelcolor(BLACK_COLOR_MAP.text_color);
   fileTree->begin();
   fileTree->add("Flintstones/Fred");
   fileTree->add("Flintstones/Wilma");
   fileTree->add("Flintstones/Pebbles");
   fileTree->add("Simpsons/Homer");
   fileTree->add("Simpsons/Marge");
   fileTree->add("Simpsons/Bart");
   fileTree->add("Simpsons/Lisa");
   fileTree->end();
   main_mdi->add(fileTree);
   this->add(main_mdi);
   this->end();
}


void devWorkBench::operator()()
{
   this->end();
   this->show();
}

void devWorkBench::show(){
	Fl_Double_Window::show();
}
void devWorkBench::setTitle(const char *title){

}

void devWorkBench::clearDefaultEditor(){
   this->front_text_buffer->text("");
}

void devWorkBench::setTextOnCurrentEditor(const char *text){
	if(text)this->front_text_buffer->append( text);
}

const char *devWorkBench::getTextFromCurrentEditor(){
   return this->front_text_buffer->text();
}


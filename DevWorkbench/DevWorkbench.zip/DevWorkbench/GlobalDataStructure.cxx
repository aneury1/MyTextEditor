/*
 * GlobalDataStructure.cxx
 *
 *  Created on: Jul 31, 2018
 *      Author: aperez
 */

#include "GlobalStructure.hxx"
#include <FL/Fl_Text_Editor.h>

GlobalDataStructure _data;


GlobalDataStructure::GlobalDataStructure()
{
	main_window = new EditorWindow(this);
	this->textbuffer = new Fl_Text_Buffer(8192);
    main_menu = new MenuBar(this);
    this->editor = new Fl_Text_Editor(3,50,main_window->w()-20, main_window->h());
    this->editor->buffer(this->textbuffer);
    this->editor->textcolor(0xFFFFFFFF);
    this->editor->textsize(24);
    this->editor->color(0x50555bFF);
}

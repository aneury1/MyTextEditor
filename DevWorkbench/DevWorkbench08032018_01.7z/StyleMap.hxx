/*
 * StyleMap.hxx
 *
 *  Created on: Aug 2, 2018
 *      Author: aperez
 */

#ifndef STYLEMAP_HXX_
#define STYLEMAP_HXX_
#include <FL/Enumerations.h>

struct ColorMap
{
	Fl_Color background_color;
	Fl_Color text_color;
	Fl_Color menu_bar_color;
	Fl_Color menu_bar_post_bg;
	Fl_Color text_menu_bar_color;
	Fl_Color task_color;
	Fl_Color tab_color;
	Fl_Color text_default_color;
	Fl_Color text_editor_bg_color;
};

static const ColorMap BLACK_COLOR_MAP=
{
	0x2f3238FF,
	0xFFFFFFFF,
	0x2f3238FF,
	0x616368FF,
	0xFFFFFFFF,
	0x1645e0FF,
    0x323338ff,
	0xFFFFFFFF,
	0x232730FF
};

#endif /* STYLEMAP_HXX_ */

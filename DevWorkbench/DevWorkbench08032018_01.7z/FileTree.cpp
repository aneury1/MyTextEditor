/*
 * FileTree.cpp
 *
 *  Created on: Aug 3, 2018
 *      Author: aperez
 */

#include "FileTree.h"

namespace {
// INTERNAL: Parse elements from 'path' into an array of null terminated strings
//    Handles escape characters, ignores multiple /'s.
//    Path="/aa/bb", returns arr[0]="aa", arr[1]="bb", arr[2]=0.
//    Caller must call free_path(arr).
//
char **parse_path(const char *path) {
  size_t len = strlen(path);
  char *cp = new char[(len+1)], *word = cp, *s = cp; // freed below or in free_path()
  char **ap = new char*[(len+1)], **arr = ap;	     // overallocates arr[]
  while (1) {
    if (*path =='/' || *path == 0) {		// handle path sep or eos
      if (word != s) { *s++ = 0; *arr++= word; word = s; }
      if ( !*path++) break; else continue;	// eos? done, else cont
    } else if ( *path == '\\' ) {		// handle escape
      if ( *(++path) ) { *s++ = *path++; } else continue;
    } else { *s++ = *path++; }			// handle normal char
  }
  *arr = 0;
  if ( arr == ap ) delete[] cp;	// empty arr[]? delete since free_path() can't
  return ap;
}

// INTERNAL: Free an array 'arr' returned by parse_path()
void free_path(char **arr) {
  if ( arr ) {
    if ( arr[0] ) { delete[] arr[0]; }	// deletes cp in parse_path
    delete[] arr;  			// deletes ptr array
  }
}
}










FileTree::FileTree(int X, int Y, int W, int H, const char *L): Fl_Tree(X,Y,W,H,L)
{
  this->labelcolor(0xFFFFFFFF);
  this->color(0x0f0f0f);
  root()->parent(0);				// we are root of tree
  root()->label("principal");
  root()->labelcolor(0xFFFFFFF);
  item_labelfgcolor(0xFFFFFFFF);connectorcolor(0xFFFFFFFF);

}

Fl_Tree_Item *FileTree::add(const char *path)
{
  return this->add(path, (Fl_Tree_Item *)0);
}
Fl_Tree_Item *FileTree::add(const char *path, Fl_Tree_Item *item)
{
	  if ( !root() ) {
	#if FLTK_ABI_VERSION >= 10303
		  root(new Fl_Tree_Item(this));
	#else
	      root(new Fl_Tree_Item(prefs()));
	#endif

	    root()->parent(0);
	    root()->label("Principal...");
	  }
	  // Find parent item via path
	  char **arr = parse_path(path);


	  item = root()->add(prefs(), arr, item);

	  free_path(arr);

	  return(item);
}

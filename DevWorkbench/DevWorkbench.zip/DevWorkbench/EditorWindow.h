/*
 * EditorWindow.h
 *
 *  Created on: Aug 1, 2018
 *      Author: aperez
 */

#ifndef EDITORWINDOW_H_
#define EDITORWINDOW_H_
#include <FL/Fl_Double_Window.h>
#include <FL/Fl_Menu_Item.h>
#include <FL/Fl_Menu_Bar.h>
#include "GlobalStructure.hxx"

struct GlobalDataStructure;

class EditorWindow : public Fl_Double_Window{
   GlobalDataStructure *data;
public:
    EditorWindow(GlobalDataStructure *data);
    int w();
    int h();
};

#endif /* EDITORWINDOW_H_ */

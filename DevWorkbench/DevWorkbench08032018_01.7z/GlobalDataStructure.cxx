/*
 * GlobalDataStructure.cxx
 *
 *  Created on: Jul 31, 2018
 *      Author: aperez
 */

#include "GlobalStructure.hxx"


GlobalDataStructure _data;

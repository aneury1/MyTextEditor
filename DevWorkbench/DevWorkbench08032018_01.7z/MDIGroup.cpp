/*
 * MDIGroup.cpp
 *
 *  Created on: Aug 3, 2018
 *      Author: aperez
 */

#include "MDIGroup.h"

MDIGroup::MDIGroup(int x ,int y,int w,int h, const char *label): Fl_Group(x,y,w,h,label)
{

}

void MDIGroup::add(Fl_Widget *w)
{
   int x= w->x();
   int y= w->y();
   w->position(this->x() + x, this->y() + y);
   Fl_Group::add(w);
}

#ifndef MENUBAR_H_
#define MENUBAR_H_
#include <string>
#include <map>
#include <FL/Enumerations.H>
#include <FL/Fl_Menu_Bar.h>
#include <FL/Fl_Menu_Item.h>
#include "GlobalStructure.hxx"
using std::string;
using std::map;

struct GlobalDataStructure;


class MenuBar : public Fl_Menu_Bar
{
   Fl_Menu_Item plugin_item[255];
   Fl_Menu_Item default_items[512];
   GlobalDataStructure *data;

public:

  MenuBar(GlobalDataStructure *data);


};

#endif /* MENUBAR_H_ */

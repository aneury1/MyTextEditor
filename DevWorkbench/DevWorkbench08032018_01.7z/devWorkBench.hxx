
#ifndef DEVWORKBENCH_HXX_
#define DEVWORKBENCH_HXX_
#include <FL/Fl_Double_Window.h>
#include <Fl/Fl.H>
#include <Fl/Fl_Group.H>
#include <Fl/Fl_Text_Display.H>
#include <Fl/Fl_Text_Editor.h>
#include <Fl/Fl_Text_Buffer.h>
#include <Fl/Fl_Menu_Bar.h>
#include <Fl/Fl_Box.h>

#include "MDIGroup.h"
#include "FileTree.h"

class devWorkBench : public Fl_Double_Window
{

    devWorkBench();

    static devWorkBench* singleObject;

   /// Fl_Group *workbench; ///in order to add Tabs, but in this version I cant do it.

    ///Menu Bar
    Fl_Menu_Bar *menubar;

    ///our def. Editor.
    Fl_Text_Editor* editor;
    Fl_Text_Buffer * front_text_buffer;
    Fl_Text_Buffer * colored_text_buffer;


    MDIGroup *main_mdi;
    FileTree *fileTree;
    //Fl_Box *status_bar;

public:

    static devWorkBench *get()
    {
    	if(!singleObject)
    		singleObject = new devWorkBench();
    	return singleObject;
    }

    void operator()();
    void show();
    void setTitle(const char *title);

private:
    ////handler our main mdi.
    void addMDIInterface();
    void createDefaultEditor();

public:
    void clearDefaultEditor();
    void setTextOnCurrentEditor(const char *text);
    const char *getTextFromCurrentEditor();

    ///this function is need later
    void createOneEditorAndAddToTheGroup(){}





};



#endif /* DEVWORKBENCH_HXX_ */

/*
 * GlobalStructure.hxx
 *
 *  Created on: Jul 31, 2018
 *      Author: aperez
 */

#ifndef GLOBALSTRUCTURE_HXX_
#define GLOBALSTRUCTURE_HXX_

#include "EditorWindow.h"
#include "MenuBar.h"
#include <FL/Fl_Double_Window.h>
#include <FL/Fl_Menu_Item.h>
#include <FL/Fl_Menu_Bar.h>
#include <FL/Fl_Text_Buffer.h>
///#include <FL/Fl_Text_Editor.h>
class MenuBar;
class EditorWindow;
class Fl_Text_Editor;

struct GlobalDataStructure
{
	EditorWindow      *main_window;
	MenuBar           *main_menu;
	Fl_Text_Buffer    *textbuffer;
	Fl_Text_Editor    *editor;
	GlobalDataStructure();
};

extern GlobalDataStructure _data;



#endif /* GLOBALSTRUCTURE_HXX_ */

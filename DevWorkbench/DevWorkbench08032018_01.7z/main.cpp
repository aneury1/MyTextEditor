
#include "devWorkBench.hxx"


int main(int argc, char *argv[])
{
	devWorkBench::get()->show();
    return Fl::run();
}

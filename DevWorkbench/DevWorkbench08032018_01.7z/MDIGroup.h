/*
 * MDIGroup.h
 *
 *  Created on: Aug 3, 2018
 *      Author: aperez
 */

#ifndef MDIGROUP_H_
#define MDIGROUP_H_
#include <Fl/Fl_Group.h>

class MDIGroup : public Fl_Group
{
public:
	MDIGroup(int x ,int y,int w,int h, const char *label = 0);

	void add(Fl_Widget *w);
};

#endif /* MDIGROUP_H_ */

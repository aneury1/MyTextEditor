/*
 * EditorWindow.cpp
 *
 *  Created on: Aug 1, 2018
 *      Author: aperez
 */
#include <stdio.h>
#include <FL/Fl.H>
#include <FL/Fl_Double_Window.h>
#include <FL/Fl_Menu_Item.h>
#include <FL/Fl_Menu_Bar.h>
#include "EditorWindow.h"

EditorWindow::EditorWindow(GlobalDataStructure *data):Fl_Double_Window(0,0,Fl::w()-10, Fl::h()-40,"UNTITLED"), data(data)
{
	printf("Creando ventana");
	color(fl_rgb_color(80, 85, 91));
}


int EditorWindow::w(){return Fl_Double_Window::w();}
int EditorWindow::h(){return Fl_Double_Window::h();}
